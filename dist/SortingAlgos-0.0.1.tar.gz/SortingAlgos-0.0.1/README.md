#Sorting Algorithms Package

*This package contains sorting techniques -*
1. BeadSort
2. BubbleSort
3. CombSort
4. CountSort
5. CycleSort
6. InsertionSort
7. MergeSort
8. PancakeSort
9. PigeonholeSort
10. QuickSort
11. RadixSort
12. SelectionSort
13. ShellSort
14. SleepSort
15. TimSort

*To optimize the code use sorting techniques whose time complexity is lowest
and works faster*
